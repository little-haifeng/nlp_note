<!-- _coverpage.md -->

<!-- ![logo](bilibili.jpg) -->
<img width="160px" style="border-radius: 50%" bor src="2.webp"></img>

# NLP NOTE <small>3.5</small>

> 一个神奇的文档网站生成器。

- 简单、轻便 (压缩后 ~21kB)
- 无需生成 html 文件
- 众多主题

[GitHub](https://github.com/little-haifeng/nlp_note)
[Get Started](README)

<!-- ![color](#ff70ac82) -->